document.getElementById('ping').addEventListener('click', async () => {
  const out = document.getElementById('out');
  out.textContent = 'Fetching / ...';
  try {
    const res = await fetch('/');
    out.textContent = 'Status: ' + res.status + ' ' + res.statusText;
  } catch (e) {
    out.textContent = 'Error: ' + e.message;
  }
});

document.getElementById('boom').addEventListener('click', async () => {
  const out = document.getElementById('out');
  try {
    const res = await fetch('/throw');
    out.textContent = 'Status: ' + res.status + ' ' + res.statusText;
  } catch (e) {
    out.textContent = 'Error: ' + e.message;
  }
});