using Microsoft.AspNetCore.StaticFiles;

var builder = WebApplication.CreateBuilder(args);

// Logging is added by default; HSTS config here for clarity
builder.Services.AddHsts(options =>
{
    options.Preload = true;
    options.IncludeSubDomains = true;
    options.MaxAge = TimeSpan.FromDays(365);
});

var app = builder.Build();

// Error handling: dev vs prod
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/error"); // custom error endpoint below
    app.UseHsts();
}
else
{
    app.UseDeveloperExceptionPage();
}

// 1) Always redirect HTTP -> HTTPS
app.UseHttpsRedirection();

// 2) Security headers + Content-Security-Policy applied to every response
app.Use(async (context, next) =>
{
    context.Response.Headers["Content-Security-Policy"] =
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'";
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-Frame-Options"] = "DENY";
    context.Response.Headers["Referrer-Policy"] = "no-referrer";
    context.Response.Headers["Permissions-Policy"] = "geolocation=()";
    await next();
});

// 3) Custom request/response logging middleware
app.UseMiddleware<RequestResponseLoggingMiddleware>();

// 4) Static files from wwwroot with extra caching for performance
app.UseStaticFiles(new StaticFileOptions
{
    OnPrepareResponse = ctx =>
    {
        ctx.Context.Response.Headers["Cache-Control"] = "public, max-age=604800, immutable"; // 7 days
    }
});

// A route to deliberately throw, to test error page & logging
app.MapGet("/throw", () => { throw new Exception("Boom! Test exception"); });

// Custom error endpoint used by UseExceptionHandler above
app.MapGet("/error", (HttpContext http) =>
{
    http.Response.ContentType = "text/html; charset=utf-8";
    const string html = @"<!doctype html>
    <html lang=""en"">
    <head><meta charset=""utf-8""><title>Error</title></head>
    <body style=""font-family: system-ui; max-width: 60ch; margin: 4rem auto;"">
      <h1>Oops! Something went wrong.</h1>
      <p>Please try again later. If the issue persists, contact support.</p>
      <p><a href=""/"">Back to Home</a></p>
    </body>
    </html>";
    return Results.Content(html);
});

app.Run();

// --------------- Custom Middleware ---------------
public sealed class RequestResponseLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestResponseLoggingMiddleware> _logger;

    public RequestResponseLoggingMiddleware(RequestDelegate next, ILogger<RequestResponseLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var req = context.Request;
        _logger.LogInformation("➡️ Incoming {Method} {Path} ({Scheme})", req.Method, req.Path, req.Scheme);

        // Continue down the pipeline
        await _next(context);

        var status = context.Response.StatusCode;
        _logger.LogInformation("⬅️ Outgoing {StatusCode} for {Method} {Path}", status, req.Method, req.Path);
    }
}