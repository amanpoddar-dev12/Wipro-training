using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPagesDemo.Pages.Items;

public class CreateModel : PageModel
{
    private readonly ItemRepository _repo;
    public CreateModel(ItemRepository repo) => _repo = repo;

    [BindProperty]
    public string Name { get; set; } = string.Empty;

    public void OnGet() { }

    public IActionResult OnPost()
    {
        if (string.IsNullOrWhiteSpace(Name))
        {
            ModelState.AddModelError(nameof(Name), "Name is required.");
            return Page();
        }

        _repo.Add(Name.Trim());
        return RedirectToPage("Index");
    }
}