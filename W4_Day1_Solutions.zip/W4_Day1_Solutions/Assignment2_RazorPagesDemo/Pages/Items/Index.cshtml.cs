using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPagesDemo.Pages.Items;

public class IndexModel : PageModel
{
    private readonly ItemRepository _repo;
    public IndexModel(ItemRepository repo) => _repo = repo;

    public IEnumerable<Item> Items { get; private set; } = Enumerable.Empty<Item>();

    public void OnGet()
    {
        Items = _repo.GetAll();
    }
}