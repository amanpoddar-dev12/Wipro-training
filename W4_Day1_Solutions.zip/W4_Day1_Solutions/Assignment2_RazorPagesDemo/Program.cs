var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddSingleton<ItemRepository>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapRazorPages();
app.Run();

// ----------------- Simple in-memory model + repo -----------------
public record Item(int Id, string Name);

public sealed class ItemRepository
{
    private readonly List<Item> _items = new();
    private int _nextId = 1;

    public IEnumerable<Item> GetAll() => _items;

    public Item Add(string name)
    {
        var item = new Item(_nextId++, name);
        _items.Add(item);
        return item;
    }
}