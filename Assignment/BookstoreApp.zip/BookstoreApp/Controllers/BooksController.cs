
using Microsoft.AspNetCore.Mvc;
using BookstoreApp.Data;
using BookstoreApp.Models;

namespace BookstoreApp.Controllers
{
    public class BooksController : Controller
    {
        private readonly DatabaseHelper _dbHelper;

        public BooksController(IConfiguration configuration)
        {
            _dbHelper = new DatabaseHelper(configuration.GetConnectionString("DefaultConnection"));
        }

        public IActionResult Index()
        {
            var books = _dbHelper.GetBooks();
            return View(books);
        }

        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _dbHelper.AddBook(book);
                return RedirectToAction("Index");
            }
            return View(book);
        }
    }
}
