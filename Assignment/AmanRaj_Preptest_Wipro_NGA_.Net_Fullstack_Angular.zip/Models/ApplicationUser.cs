using Microsoft.AspNetCore.Identity;

namespace SecureLoginApp.Models
{
    public class ApplicationUser : IdentityUser {}
}