# Book Management REST API

## Setup

1. Run `npm install`
2. Start server: `npm start`

## Endpoints

- GET /books
- GET /books/:id
- POST /books
- PUT /books/:id
- DELETE /books/:id
