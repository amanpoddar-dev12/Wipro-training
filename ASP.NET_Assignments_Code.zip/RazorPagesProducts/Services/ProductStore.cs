using System.Collections.Concurrent;
using RazorPagesProducts.Models;

namespace RazorPagesProducts.Services
{
    public class ProductStore
    {
        private readonly ConcurrentDictionary<int, Product> _store = new();
        private int _seq = 1;
        public IEnumerable<Product> All() => _store.Values.OrderBy(p => p.ProductID);
        public Product? Get(int id) => _store.TryGetValue(id, out var p) ? p : null;
        public int Add(Product product)
        {
            var id = Interlocked.Increment(ref _seq);
            product.ProductID = id;
            for (int i = 0; i < product.Categories.Count; i++)
                product.Categories[i].CategoryID = i + 1;
            _store[id] = product;
            return id;
        }
    }
}
