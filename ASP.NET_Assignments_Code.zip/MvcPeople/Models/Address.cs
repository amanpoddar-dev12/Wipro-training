using System.ComponentModel.DataAnnotations;

namespace MvcPeople.Models
{
    public class Address
    {
        [Required] public string Street { get; set; } = string.Empty;
        [Required] public string City { get; set; } = string.Empty;
        [Required, RegularExpression(@"^[0-9]{5,6}$", ErrorMessage = "Zip must be 5-6 digits")]
        public string ZipCode { get; set; } = string.Empty;
    }
}
