using System.ComponentModel.DataAnnotations;

namespace MvcPeople.Models
{
    public class Person
    {
        [Required] public string FirstName { get; set; } = string.Empty;
        [Required] public string LastName { get; set; } = string.Empty;
        [Range(0, 150)] public int Age { get; set; }
        public Address Address { get; set; } = new();
    }
}
