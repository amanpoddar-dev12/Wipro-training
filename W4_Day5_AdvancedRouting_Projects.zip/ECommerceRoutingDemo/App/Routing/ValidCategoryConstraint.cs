using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace ECommerceRoutingDemo.Routing
{
    public class ValidCategoryConstraint : IRouteConstraint
    {
        private static readonly HashSet<string> Allowed = new(new[] { "electronics", "books", "clothing", "grocery" });
        public bool Match(HttpContext? httpContext, IRouter? route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
        {
            if (!values.TryGetValue(routeKey, out var raw) || raw is null) return false;
            return Allowed.Contains(raw.ToString()!.ToLowerInvariant());
        }
    }
}