using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace ECommerceRoutingDemo.Routing
{
    // Accepts formats like 0-100, 100-500, 999-9999
    public class PriceRangeConstraint : IRouteConstraint
    {
        private static readonly Regex Pattern = new(@"^(\d+)-(\d+)$");
        public bool Match(HttpContext? httpContext, IRouter? route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
        {
            if (!values.TryGetValue(routeKey, out var raw) || raw is null) return false;
            var s = raw.ToString()!;
            var m = Pattern.Match(s);
            if (!m.Success) return false;
            return int.Parse(m.Groups[1].Value) <= int.Parse(m.Groups[2].Value);
        }
    }
}