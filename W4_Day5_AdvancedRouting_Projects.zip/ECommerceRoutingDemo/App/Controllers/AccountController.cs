using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ECommerceRoutingDemo.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet("Account/Login")]
        public IActionResult Login(string? returnUrl = "/")
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost("Account/Login")]
        public async Task<IActionResult> LoginPost(string username, string returnUrl = "/")
        {
            // Simple demo sign-in (cookie)
            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, username ?? "guest")
            }, "Cookies");
            await Microsoft.AspNetCore.Authentication.AuthenticationHttpContextExtensions.SignInAsync(HttpContext, "Cookies", new ClaimsPrincipal(identity));
            return Redirect(returnUrl);
        }
    }
}