using Microsoft.AspNetCore.Mvc;

namespace ECommerceRoutingDemo.Controllers
{
    [Route("Products")]
    public class ProductsController : Controller
    {
        // /Products/{category}/{id}
        [HttpGet("{category:category}/{id:int}")]
        public IActionResult Details(string category, int id)
        {
            ViewData["Category"] = category;
            ViewData["Id"] = id;
            return View();
        }

        // /Products/Filter/{category}/{priceRange}
        [HttpGet("Filter/{category:category}/{priceRange:price}")]
        public IActionResult Filter(string category, string priceRange)
        {
            ViewData["Category"] = category;
            ViewData["PriceRange"] = priceRange;
            return View();
        }
    }
}