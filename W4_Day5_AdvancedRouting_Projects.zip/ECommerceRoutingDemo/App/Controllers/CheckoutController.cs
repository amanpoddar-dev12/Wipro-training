using Microsoft.AspNetCore.Mvc;

namespace ECommerceRoutingDemo.Controllers
{
    public class CheckoutController : Controller
    {
        // /Checkout -> redirect to /Account/Login if not authenticated
        [HttpGet("Checkout")]
        public IActionResult Index()
        {
            if (!User.Identity?.IsAuthenticated ?? true)
                return Redirect("/Account/Login?returnUrl=/Checkout");
            return View();
        }
    }
}