using System.Net;
using System.Threading.Tasks;
using ECommerceRoutingDemo;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

public class RoutingTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    public RoutingTests(WebApplicationFactory<Program> factory) => _factory = factory;

    [Theory]
    [InlineData("/Products/electronics/25")]
    [InlineData("/Products/Filter/books/0-100")]
    public async Task Routes_Return_OK(string url)
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        var res = await client.GetAsync(url);
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
    }

    [Fact]
    public async Task Checkout_Redirects_When_Not_Logged_In()
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        var res = await client.GetAsync("/Checkout");
        Assert.Equal(HttpStatusCode.Redirect, res.StatusCode);
        Assert.Equal("/Account/Login?returnUrl=/Checkout", res.Headers.Location?.ToString());
    }
}