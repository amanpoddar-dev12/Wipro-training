using Microsoft.AspNetCore.Mvc;

namespace AdvancedRoutingDemo.Controllers
{
    // Complex route: /Products/{category}/{id}
    [Route("Products")]
    public class ProductsController : Controller
    {
        [HttpGet("{category:category}/{id:int}")]
        public IActionResult Details(string category, int id)
        {
            ViewData["Category"] = category;
            ViewData["Id"] = id;
            return View();
        }
    }
}