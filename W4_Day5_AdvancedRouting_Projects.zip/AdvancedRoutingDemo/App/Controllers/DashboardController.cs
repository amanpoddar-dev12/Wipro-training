
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace AdvancedRoutingDemo.Controllers
{
    public class DashboardController : Controller
    {
        // Dynamic routing by role: admin sees Admin view; others see User view.
        [HttpGet("Dashboard")]
        public IActionResult Index()
        {
            if (User.IsInRole("Admin"))
                return View("Admin");
            return View("User");
        }

        // Helper endpoints to sign in as Admin/User for demo (cookie auth)
        [HttpGet("Auth/LoginAsAdmin")]
        public async Task<IActionResult> LoginAsAdmin()
        {
            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, "admin"),
                new Claim(ClaimTypes.Role, "Admin")
            }, "Cookies");
            await Microsoft.AspNetCore.Authentication.AuthenticationHttpContextExtensions.SignInAsync("Cookies", new ClaimsPrincipal(identity));
            return Redirect("/Dashboard");
        }

        [HttpGet("Auth/LoginAsUser")]
        public async Task<IActionResult> LoginAsUser()
        {
            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, "jane"),
                new Claim(ClaimTypes.Role, "User")
            }, "Cookies");
            await Microsoft.AspNetCore.Authentication.AuthenticationHttpContextExtensions.SignInAsync("Cookies", new ClaimsPrincipal(identity));
            return Redirect("/Dashboard");
        }
    }
}
