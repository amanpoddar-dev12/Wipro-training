using Microsoft.AspNetCore.Mvc;

namespace AdvancedRoutingDemo.Controllers
{
    // Complex route: /Users/{username}/Orders
    [Route("Users")]
    public class UsersController : Controller
    {
        [HttpGet("{username}/Orders")]
        public IActionResult Orders(string username)
        {
            ViewData["Username"] = username;
            return View();
        }
    }
}