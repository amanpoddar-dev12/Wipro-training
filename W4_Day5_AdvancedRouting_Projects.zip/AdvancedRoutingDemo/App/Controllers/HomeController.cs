using Microsoft.AspNetCore.Mvc;

namespace AdvancedRoutingDemo.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
    }
}