using System.Net;
using System.Threading.Tasks;
using AdvancedRoutingDemo;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

public class RoutingTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    public RoutingTests(WebApplicationFactory<Program> factory) => _factory = factory;

    [Theory]
    [InlineData("/Products/electronics/10")]
    [InlineData("/Users/john/Orders")]
    public async Task Complex_Routes_Return_OK(string url)
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        var res = await client.GetAsync(url);
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
    }

    [Fact]
    public async Task Dynamic_Route_Admin_Sees_Admin_Dashboard()
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        var login = await client.GetAsync("/Auth/LoginAsAdmin");
        Assert.Equal(HttpStatusCode.Redirect, login.StatusCode);
        var res = await client.GetAsync("/Dashboard");
        Assert.Equal(HttpStatusCode.OK, res.StatusCode);
        var html = await res.Content.ReadAsStringAsync();
        Assert.Contains("Admin Dashboard", html);
    }
}