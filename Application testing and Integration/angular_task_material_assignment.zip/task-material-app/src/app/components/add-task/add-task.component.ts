import { Component } from '@angular/core';
import { Task } from '../../services/task.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html'
})
export class AddTaskComponent {
  newTask: string = '';
  localTasks: Task[] = [];

  addTask() {
    if (this.newTask.trim()) {
      this.localTasks.push({ title: this.newTask, completed: false });
      this.newTask = '';
    }
  }
}
