import { Component, OnInit } from '@angular/core';
import { TaskService, Task } from '../../services/task.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html'
})
export class TaskListComponent implements OnInit {
  tasks: Task[] = [];
  error: string | null = null;

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks() {
    this.taskService.getTasks().subscribe({
      next: (data) => this.tasks = data,
      error: () => this.error = 'Failed to load tasks. Please try again later.'
    });
  }

  toggleTask(task: Task) {
    task.completed = !task.completed;
  }

  completeAll() {
    this.tasks.forEach(task => task.completed = true);
  }
}
