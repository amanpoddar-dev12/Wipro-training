import { Component } from '@angular/core';
import { TaskService, Task } from '../../services/task.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html'
})
export class AddTaskComponent {
  title: string = '';
  description: string = '';
  error: string | null = null;

  constructor(private taskService: TaskService) {}

  addTask() {
    const newTask: Task = { title: this.title, description: this.description, status: 'pending' };
    this.taskService.addTask(newTask).subscribe({
      next: () => {
        this.title = '';
        this.description = '';
        this.error = null;
      },
      error: () => this.error = 'Failed to add task.'
    });
  }
}
