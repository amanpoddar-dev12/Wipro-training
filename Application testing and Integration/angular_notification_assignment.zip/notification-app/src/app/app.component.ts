import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  showNotification = true;

  handleNotificationClose() {
    this.showNotification = false;
    console.log('Notification closed');
  }
}
