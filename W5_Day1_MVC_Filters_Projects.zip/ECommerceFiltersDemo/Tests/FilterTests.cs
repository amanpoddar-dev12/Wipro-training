using System.Net;
using System.Threading.Tasks;
using ECommerceFiltersDemo;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

public class FilterTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    public FilterTests(WebApplicationFactory<Program> factory) => _factory = factory;

    [Fact]
    public async Task CustomAuthFilter_Protects_ManageProducts()
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        var res = await client.GetAsync("/Products/Manage");
        Assert.Equal(HttpStatusCode.Redirect, res.StatusCode);
        Assert.Equal("/Account/Login?returnUrl=/Products/Manage", res.Headers.Location?.ToString());
    }

    [Fact]
    public async Task GlobalExceptionFilter_Handles_Unhandled_Errors()
    {
        var client = _factory.CreateClient();
        var res = await client.GetAsync("/Home/Throw");
        var html = await res.Content.ReadAsStringAsync();
        Assert.Contains("Something went wrong", html);
    }
}