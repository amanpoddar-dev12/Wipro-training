using Microsoft.AspNetCore.Mvc;

namespace ECommerceFiltersDemo.Controllers
{
    [ServiceFilter(typeof(ECommerceFiltersDemo.Filters.LoggingActionFilter))]
    [Route("Products")]
    public class ProductsController : Controller
    {
        [HttpGet("")]
        public IActionResult Index() => View();

        [ECommerceFiltersDemo.Filters.CustomAuthFilter]
        [HttpGet("Manage")]
        public IActionResult Manage() => View(); // Requires login via CustomAuthFilter
    }
}