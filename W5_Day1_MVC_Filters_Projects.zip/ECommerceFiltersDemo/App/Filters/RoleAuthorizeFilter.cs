using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Linq;
using System.Threading.Tasks;

namespace ECommerceFiltersDemo.Filters
{
    // Restricts access to users with any of the supplied roles (via attribute)
    public class RoleAuthorizeFilter : IAsyncActionFilter
    {
        private readonly string[] _roles;
        public RoleAuthorizeFilter(string rolesCsv = "") => _roles = rolesCsv.Split(',', System.StringSplitOptions.RemoveEmptyEntries).Select(r => r.Trim()).ToArray();

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var user = context.HttpContext.User;
            if (!(_roles?.Length > 0))
            {
                await next();
                return;
            }
            bool ok = _roles.Any(role => user.IsInRole(role));
            if (!ok)
            {
                context.Result = new ForbidResult();
                return;
            }
            await next();
        }
    }

    // Helper attribute so we can pass roles and still use DI via TypeFilterAttribute
    public class RolesAttribute : TypeFilterAttribute
    {
        public RolesAttribute(string rolesCsv) : base(typeof(RoleAuthorizeFilter))
        {
            Arguments = new object[] { rolesCsv };
        }
    }
}