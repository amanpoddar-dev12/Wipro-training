using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ECommerceFiltersDemo.Filters
{
    // Logs request path, method, and elapsed time + status code (if available)
    public class LoggingActionFilter : IAsyncActionFilter
    {
        private readonly ILogger<LoggingActionFilter> _logger;
        public LoggingActionFilter(ILogger<LoggingActionFilter> logger) => _logger = logger;

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var sw = Stopwatch.StartNew();
            var req = context.HttpContext.Request;
            _logger.LogInformation("Request: {Method} {Path}", req.Method, req.Path);
            var executed = await next();
            sw.Stop();
            var status = executed?.HttpContext?.Response?.StatusCode;
            _logger.LogInformation("Response: Status={Status} Elapsed={Elapsed}ms", status, sw.ElapsedMilliseconds);
        }
    }
}