using System.Net;
using System.Threading.Tasks;
using BankingFiltersDemo;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

public class FilterTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    public FilterTests(WebApplicationFactory<Program> factory) => _factory = factory;

    [Fact]
    public async Task AuthFilter_Protects_Transactions()
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        var res = await client.GetAsync("/Bank/Transactions");
        Assert.Equal(HttpStatusCode.Redirect, res.StatusCode);
        Assert.Equal("/Account/Login?returnUrl=/Bank/Transactions", res.Headers.Location?.ToString());
    }

    [Fact]
    public async Task RoleFilter_Blocks_Non_Admin_On_AllAccounts()
    {
        var client = _factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
        // Not logged in -> Forbid (due to Roles filter)
        var res = await client.GetAsync("/Bank/Admin/AllAccounts");
        Assert.Equal(HttpStatusCode.Forbidden, res.StatusCode);
    }

    [Fact]
    public async Task GlobalExceptionFilter_Shows_Error_Page()
    {
        var client = _factory.CreateClient();
        var res = await client.GetAsync("/Bank/CauseError");
        var html = await res.Content.ReadAsStringAsync();
        Assert.Contains("Something went wrong", html);
    }
}