using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Threading.Tasks;

namespace BankingFiltersDemo.Filters
{
    // Ensures the user is authenticated; otherwise redirects to /Account/Login
    public class CustomAuthFilter : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var user = context.HttpContext.User;
            if (!(user?.Identity?.IsAuthenticated ?? false))
            {
                context.Result = new RedirectResult("/Account/Login?returnUrl=" + context.HttpContext.Request.Path);
                return;
            }
            await next();
        }
    }
}