using Microsoft.AspNetCore.Mvc;

namespace BankingFiltersDemo.Controllers
{
    [ServiceFilter(typeof(BankingFiltersDemo.Filters.LoggingActionFilter))]
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
        [HttpGet("Home/Throw")]
        public IActionResult Throw() => throw new System.Exception("Boom!");

    }
}