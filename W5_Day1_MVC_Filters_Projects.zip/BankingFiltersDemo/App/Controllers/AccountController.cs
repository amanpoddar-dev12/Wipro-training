using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BankingFiltersDemo.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet("Account/Login")]
        public IActionResult Login(string? returnUrl = "/")
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost("Account/Login")]
        public async Task<IActionResult> LoginPost(string username, string returnUrl = "/")
        {
            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, username ?? "guest"),
                // Make 'admin' username get Admin role for demo
                new Claim(ClaimTypes.Role, (username == "admin") ? "Admin" : "User")
            }, "Cookies");
            await Microsoft.AspNetCore.Authentication.AuthenticationHttpContextExtensions.SignInAsync(HttpContext, "Cookies", new ClaimsPrincipal(identity));
            return Redirect(returnUrl);
        }
    }
}