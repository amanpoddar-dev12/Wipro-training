using Microsoft.AspNetCore.Mvc;

namespace BankingFiltersDemo.Controllers
{
    [ServiceFilter(typeof(BankingFiltersDemo.Filters.LoggingActionFilter))]
    [Route("Bank")]
    public class BankController : Controller
    {
        // Transaction list - requires authentication
        [BankingFiltersDemo.Filters.CustomAuthFilter]
        [HttpGet("Transactions")]
        public IActionResult Transactions() => View();

        // Admin-only all accounts view
        [BankingFiltersDemo.Filters.Roles("Admin")]
        [HttpGet("Admin/AllAccounts")]
        public IActionResult AllAccounts() => View();

        // Action to simulate an exception for testing global error filter
        [HttpGet("CauseError")]
        public IActionResult CauseError() => throw new System.Exception("Bank error");
    }
}