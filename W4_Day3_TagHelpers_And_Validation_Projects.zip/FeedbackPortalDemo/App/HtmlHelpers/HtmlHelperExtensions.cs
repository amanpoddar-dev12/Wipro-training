using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FeedbackPortalDemo.HtmlHelpers
{
    public static class HtmlHelperExtensions
    {
        // Renders a styled input with placeholder and classes
        public static IHtmlContent StyledInput(this IHtmlHelper html, string name, string placeholder, string cssClass)
        {
            var tb = new TagBuilder("input");
            tb.Attributes["name"] = name;
            tb.Attributes["id"] = name;
            tb.Attributes["placeholder"] = placeholder;
            tb.Attributes["type"] = "text";
            tb.AddCssClass(cssClass);
            var writer = new System.IO.StringWriter();
            tb.WriteTo(writer, System.Text.Encodings.Web.HtmlEncoder.Default);
            return new HtmlString(writer.ToString());
        }
    }
}