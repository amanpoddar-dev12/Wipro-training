using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Text;

namespace FeedbackPortalDemo.TagHelpers
{
    [HtmlTargetElement("star-rating", Attributes = "for,max")]
    public class StarRatingTagHelper : TagHelper
    {
        public string For { get; set; } = "Rating";
        public int Max { get; set; } = 5;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Attributes.SetAttribute("class", "stars");

            var sb = new StringBuilder();
            for (int i = 1; i <= Max; i++)
            {
                string inputId = $"{For}_{i}";
                sb.AppendLine($@"<input id=""{inputId}"" name=""{For}"" type=""radio"" value=""{i}"" />
<label for=""{inputId}"">&#9733;</label>");
            }
            output.Content.SetHtmlContent(sb.ToString());
        }
    }
}