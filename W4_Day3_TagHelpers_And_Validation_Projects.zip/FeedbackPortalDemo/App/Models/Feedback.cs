using System.ComponentModel.DataAnnotations;

namespace FeedbackPortalDemo.Models
{
    public class Feedback
    {
        [Required, StringLength(80)]
        public string Name { get; set; } = string.Empty;

        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Range(1, 5)]
        public int Rating { get; set; }

        [Required, StringLength(1000)]
        public string Comments { get; set; } = string.Empty;
    }
}