using Microsoft.AspNetCore.Mvc;
using FeedbackPortalDemo.Models;
using System.Collections.Generic;

namespace FeedbackPortalDemo.Controllers
{
    public class FeedbackController : Controller
    {
        // In-memory list for demo purposes
        private static readonly List<Feedback> _items = new();

        [HttpGet]
        public IActionResult Create() => View(new Feedback());

        [HttpPost]
        public IActionResult Create(Feedback model)
        {
            if (!ModelState.IsValid) return View(model);
            _items.Add(model);
            TempData["Msg"] = "Thanks for your feedback!";
            return RedirectToAction(nameof(List));
        }

        [HttpGet]
        public IActionResult List() => View(_items);
    }
}