using Microsoft.AspNetCore.Mvc;

namespace FeedbackPortalDemo.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() => View();
    }
}