using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace RegistrationValidationDemo.Models
{
    // Example custom validator: at least one digit and one letter
    public class StrongPasswordAttribute : ValidationAttribute
    {
        public int MinLength { get; set; } = 6;

        public override bool IsValid(object? value)
        {
            var s = value as string ?? string.Empty;
            if (s.Length < MinLength) return false;
            return Regex.IsMatch(s, @"[A-Za-z]") && Regex.IsMatch(s, @"\d");
        }

        public override string FormatErrorMessage(string name) => $"{name} must have letters and digits (min {MinLength} chars).";
    }
}