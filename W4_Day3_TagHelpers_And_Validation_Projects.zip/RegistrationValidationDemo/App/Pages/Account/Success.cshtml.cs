using Microsoft.AspNetCore.Mvc.RazorPages;

public class SuccessModel : PageModel
{
    public void OnGet() {}
}