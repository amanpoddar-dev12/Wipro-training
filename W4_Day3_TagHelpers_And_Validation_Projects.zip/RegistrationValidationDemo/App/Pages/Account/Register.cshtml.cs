using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RegistrationValidationDemo.Models;

namespace RegistrationValidationDemo.Pages.Account
{
    public class RegisterModel : PageModel
    {
        [BindProperty]
        public UserRegistration Input { get; set; } = new();

        public void OnGet() {}

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            TempData["Msg"] = $"Thanks {Input.Username}, registration successful!";
            return RedirectToPage("/Account/Success");
        }
    }
}