using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace BookStoreApp.Validation
{
    public class IsbnAttribute : ValidationAttribute
    {
        public IsbnAttribute() : base("Invalid ISBN (use ISBN-10 or ISBN-13).") { }
        public override bool IsValid(object? value)
        {
            if (value is not string s || string.IsNullOrWhiteSpace(s)) return false;
            s = s.Replace("-", "").Replace(" ", "");
            var isbn10 = new Regex(@"^\d{9}[\dXx]$");
            var isbn13 = new Regex(@"^\d{13}$");
            return isbn10.IsMatch(s) || isbn13.IsMatch(s);
        }
    }

    public class PriceRangeAttribute : ValidationAttribute
    {
        private readonly decimal _min; private readonly decimal _max;
        public PriceRangeAttribute(decimal min, decimal max) : base($"Price must be between {min} and {max}.")
        { _min = min; _max = max; }
        public override bool IsValid(object? value)
        {
            if (value is not decimal d) return false;
            return d >= _min && d <= _max;
        }
    }
}
