using Microsoft.AspNetCore.Mvc;
using BookStoreApp.Repositories;
using BookStoreApp.Models;
using Microsoft.AspNetCore.Authorization;

namespace BookStoreApp.Controllers
{
    public class BooksController : Controller
    {
        private readonly IBookRepository _repo;
        public BooksController(IBookRepository repo) => _repo = repo;

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var books = await _repo.GetAllAsync();
            return View(books);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int id, string? slug)
        {
            var book = await _repo.GetAsync(id);
            if (book == null) return NotFound();
            return View(book);
        }

        // Admin-only inventory management via MVC (list, edit)
        [Authorize(Policy = "AdminOnly")]
        public async Task<IActionResult> Manage()
        {
            var books = await _repo.GetAllAsync();
            return View(books);
        }
    }
}
