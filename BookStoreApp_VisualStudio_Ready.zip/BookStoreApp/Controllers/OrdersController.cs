using Microsoft.AspNetCore.Mvc;
using BookStoreApp.Services;
using BookStoreApp.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace BookStoreApp.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly IOrderService _orders;
        public OrdersController(IOrderService orders) => _orders = orders;

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout()
        {
            var cart = HttpContext.Session.GetString("cart");
            var lines = new List<(int, int)>();
            if (!string.IsNullOrEmpty(cart))
            {
                var parts = cart.Split(';', StringSplitOptions.RemoveEmptyEntries);
                foreach (var p in parts)
                {
                    var kv = p.Split(':'); // id:qty
                    if (kv.Length == 2 && int.TryParse(kv[0], out int id) && int.TryParse(kv[1], out int qty))
                        lines.Add((id, qty));
                }
            }
            int? userId = null; // In a full identity setup, map claim to user id
            var order = await _orders.CreateOrderAsync(userId, lines);
            HttpContext.Session.Remove("cart");
            return View("Confirmation", order);
        }
    }
}
