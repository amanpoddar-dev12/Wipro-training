using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BookStoreApp.Repositories;
using BookStoreApp.Models;

namespace BookStoreApp.Pages.Cart
{
    public class IndexModel : PageModel
    {
        private readonly IBookRepository _repo;
        public List<(Book book, int qty)> Lines { get; set; } = new();

        public IndexModel(IBookRepository repo) => _repo = repo;

        public async Task OnGet()
        {
            var cart = HttpContext.Session.GetString("cart");
            if (string.IsNullOrEmpty(cart)) return;
            var parts = cart.Split(';', StringSplitOptions.RemoveEmptyEntries);
            foreach (var p in parts)
            {
                var kv = p.Split(':');
                if (kv.Length == 2 && int.TryParse(kv[0], out int id) && int.TryParse(kv[1], out int qty))
                {
                    var b = await _repo.GetAsync(id);
                    if (b != null) Lines.Add((b, qty));
                }
            }
        }

        public IActionResult OnPostAdd(int id, int qty = 1)
        {
            var cart = HttpContext.Session.GetString("cart") ?? "";
            var dict = new Dictionary<int,int>();
            foreach (var item in cart.Split(';', StringSplitOptions.RemoveEmptyEntries))
            {
                var kv = item.Split(':');
                if (kv.Length == 2 && int.TryParse(kv[0], out int bid) && int.TryParse(kv[1], out int bq))
                    dict[bid] = bq;
            }
            dict[id] = dict.ContainsKey(id) ? dict[id] + qty : qty;
            var rebuilt = string.Join(';', dict.Select(kv => $"{kv.Key}:{kv.Value}"));
            HttpContext.Session.SetString("cart", rebuilt);
            return RedirectToPage();
        }

        public IActionResult OnPostRemove(int id)
        {
            var cart = HttpContext.Session.GetString("cart") ?? "";
            var dict = new Dictionary<int,int>();
            foreach (var item in cart.split(';', StringSplitOptions.RemoveEmptyEntries)) {}
            // correct remove implementation
            dict.Clear();
            foreach (var item in cart.Split(';', StringSplitOptions.RemoveEmptyEntries))
            {
                var kv = item.Split(':');
                if (kv.Length == 2 && int.TryParse(kv[0], out int bid) && int.TryParse(kv[1], out int bq))
                    if (bid != id) dict[bid] = bq;
            }
            var rebuilt = string.Join(';', dict.Select(kv => $"{kv.Key}:{kv.Value}"));
            if (string.IsNullOrEmpty(rebuilt)) HttpContext.Session.Remove("cart");
            else HttpContext.Session.SetString("cart", rebuilt);
            return RedirectToPage();
        }
    }
}
