using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;
using BookStoreApp.Models;
using BookStoreApp.Repositories;

namespace BookStoreApp.Pages.Admin.Books
{
    [Authorize(Policy = "AdminOnly")]
    public class CreateModel : PageModel
    {
        private readonly IBookRepository _repo;
        [BindProperty] public Book Book { get; set; } = new();
        public CreateModel(IBookRepository repo) => _repo = repo;
        public void OnGet() { }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();
            await _repo.AddAsync(Book);
            return RedirectToPage("/Admin/Books/Edit", new { id = Book.Id });
        }
    }
}
