using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;
using BookStoreApp.Models;
using BookStoreApp.Repositories;

namespace BookStoreApp.Pages.Admin.Books
{
    [Authorize(Policy = "AdminOnly")]
    public class EditModel : PageModel
    {
        private readonly IBookRepository _repo;
        [BindProperty] public Book Book { get; set; } = new();
        public EditModel(IBookRepository repo) => _repo = repo;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            var b = await _repo.GetAsync(id);
            if (b == null) return NotFound();
            Book = b;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();
            await _repo.UpdateAsync(Book);
            return RedirectToPage(new { id = Book.Id });
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            await _repo.DeleteAsync(id);
            return RedirectToPage("/Admin/Books/Create");
        }
    }
}
