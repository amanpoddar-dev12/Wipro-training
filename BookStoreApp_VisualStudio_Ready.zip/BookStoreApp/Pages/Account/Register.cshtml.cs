using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using BookStoreApp.Services;

namespace BookStoreApp.Pages.Account
{
    public class RegisterModel : PageModel
    {
        private readonly IUserService _users;
        public RegisterModel(IUserService users) => _users = users;

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required, EmailAddress] public string Email { get; set; } = string.Empty;
            [Required, MinLength(6)] public string Password { get; set; } = string.Empty;
        }

        public void OnGet() { }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();
            var existing = await _users.FindByEmailAsync(Input.Email);
            if (existing != null)
            {
                ModelState.AddModelError(string.Empty, "Email already registered.");
                return Page();
            }
            await _users.CreateAsync(Input.Email, Input.Password, "User");
            return RedirectToPage("/Account/Login");
        }
    }
}
