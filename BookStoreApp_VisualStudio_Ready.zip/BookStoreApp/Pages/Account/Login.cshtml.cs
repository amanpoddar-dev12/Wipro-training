using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using BookStoreApp.Services;

namespace BookStoreApp.Pages.Account
{
    public class LoginModel : PageModel
    {
        private readonly IUserService _users;
        public LoginModel(IUserService users) => _users = users;

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required, EmailAddress] public string Email { get; set; } = string.Empty;
            [Required] public string Password { get; set; } = string.Empty;
        }

        public void OnGet() { }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();
            if (!await _users.ValidateCredentialsAsync(Input.Email, Input.Password))
            {
                ModelState.AddModelError(string.Empty, "Invalid credentials.");
                return Page();
            }
            var role = await _users.GetRoleAsync(Input.Email) ?? "User";
            var claims = new List<Claim> {
                new Claim(ClaimTypes.Name, Input.Email),
                new Claim("role", role)
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(identity));
            return RedirectToAction("Index", "Books");
        }
    }
}
