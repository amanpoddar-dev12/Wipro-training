using BookStoreApp.Models;

namespace BookStoreApp.Services
{
    public interface IUserService
    {
        Task<AppUser?> FindByEmailAsync(string email);
        Task<AppUser> CreateAsync(string email, string password, string role);
        Task<bool> ValidateCredentialsAsync(string email, string password);
        Task<string?> GetRoleAsync(string email);
    }
}
