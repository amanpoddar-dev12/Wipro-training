using BookStoreApp.Data;
using BookStoreApp.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStoreApp.Services
{
    public class UserService : IUserService
    {
        private readonly AppDbContext _db;
        private readonly PasswordHasherService _hasher;
        public UserService(AppDbContext db, PasswordHasherService hasher) { _db = db; _hasher = hasher; }

        public async Task<AppUser?> FindByEmailAsync(string email) => await _db.Users.FirstOrDefaultAsync(u => u.Email == email);

        public async Task<AppUser> CreateAsync(string email, string password, string role)
        {
            var user = new AppUser { Email = email, Role = role };
            user.PasswordHash = _hasher.Hash(password);
            _db.Users.Add(user);
            await _db.SaveChangesAsync();
            return user;
        }

        public async Task<bool> ValidateCredentialsAsync(string email, string password)
        {
            var user = await FindByEmailAsync(email);
            if (user == null) return false;
            return _hasher.Verify(user.PasswordHash, password);
        }

        public async Task<string?> GetRoleAsync(string email) => (await FindByEmailAsync(email))?.Role;
    }
}
