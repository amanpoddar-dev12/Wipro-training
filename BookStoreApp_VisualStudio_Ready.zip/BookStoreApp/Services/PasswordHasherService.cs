using Microsoft.AspNetCore.Identity;

namespace BookStoreApp.Services
{
    public class PasswordHasherService
    {
        private readonly PasswordHasher<string> _hasher = new PasswordHasher<string>();
        public string Hash(string password) => _hasher.HashPassword("", password);
        public bool Verify(string hashed, string password) =>
            _hasher.VerifyHashedPassword("", hashed, password) != PasswordVerificationResult.Failed;
    }
}
