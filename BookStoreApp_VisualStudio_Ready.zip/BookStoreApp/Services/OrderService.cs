using BookStoreApp.Data;
using BookStoreApp.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStoreApp.Services
{
    public class OrderService : IOrderService
    {
        private readonly AppDbContext _db;
        public OrderService(AppDbContext db) => _db = db;

        public async Task<Order> CreateOrderAsync(int? userId, IEnumerable<(int bookId, int qty)> lines)
        {
            var order = new Order { UserId = userId };
            foreach (var (bookId, qty) in lines)
            {
                var book = await _db.Books.FirstAsync(b => b.Id == bookId);
                var item = new OrderItem
                {
                    BookId = bookId,
                    Quantity = qty,
                    LineTotal = book.Price * qty
                };
                order.Items.Add(item);
                order.Total += item.LineTotal;
            }
            _db.Orders.Add(order);
            await _db.SaveChangesAsync();
            return order;
        }
    }
}
