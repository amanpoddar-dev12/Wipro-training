using BookStoreApp.Models;

namespace BookStoreApp.Services
{
    public interface IOrderService
    {
        Task<Order> CreateOrderAsync(int? userId, IEnumerable<(int bookId, int qty)> lines);
    }
}
