using BookStoreApp.Data;
using BookStoreApp.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStoreApp.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly AppDbContext _db;
        public BookRepository(AppDbContext db) => _db = db;

        public async Task<IEnumerable<Book>> GetAllAsync() => await _db.Books.AsNoTracking().ToListAsync();
        public async Task<Book?> GetAsync(int id) => await _db.Books.FindAsync(id);
        public async Task AddAsync(Book book) { _db.Books.Add(book); await _db.SaveChangesAsync(); }
        public async Task UpdateAsync(Book book) { _db.Books.Update(book); await _db.SaveChangesAsync(); }
        public async Task DeleteAsync(int id)
        {
            var b = await _db.Books.FindAsync(id);
            if (b != null) { _db.Books.Remove(b); await _db.SaveChangesAsync(); }
        }
        public Task<bool> ExistsAsync(int id) => _db.Books.AnyAsync(b => b.Id == id);
    }
}
