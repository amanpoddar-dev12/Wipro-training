using Microsoft.EntityFrameworkCore;
using BookStoreApp.Models;

namespace BookStoreApp.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}
        public DbSet<Book> Books => Set<Book>();
        public DbSet<AppUser> Users => Set<AppUser>();
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<OrderItem> OrderItems => Set<OrderItem>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Book>().Property(b => b.Price).HasPrecision(18,2);
            modelBuilder.Entity<AppUser>().HasIndex(u => u.Email).IsUnique();
        }
    }

    public static class DbInitializer
    {
        public static async Task SeedAsync(AppDbContext db)
        {
            await db.Database.EnsureCreatedAsync();

            if (!db.Books.Any())
            {
                db.Books.AddRange(
                    new Book { Title = "Clean Code", Author = "Robert C. Martin", ISBN = "9780132350884", Price = 499.00m },
                    new Book { Title = "The Pragmatic Programmer", Author = "Andrew Hunt", ISBN = "9780201616224", Price = 599.00m },
                    new Book { Title = "CLR via C#", Author = "Jeffrey Richter", ISBN = "9780735667457", Price = 799.00m }
                );
            }
            if (!db.Users.Any())
            {
                var hasher = new Services.PasswordHasherService();
                var admin = new Models.AppUser { Email = "admin@bookstore.local", Role = "Admin" };
                admin.PasswordHash = hasher.Hash("Admin@123");
                var user = new Models.AppUser { Email = "user@bookstore.local", Role = "User" };
                user.PasswordHash = hasher.Hash("User@123");
                db.Users.AddRange(admin, user);
            }
            await db.SaveChangesAsync();
        }
    }
}
