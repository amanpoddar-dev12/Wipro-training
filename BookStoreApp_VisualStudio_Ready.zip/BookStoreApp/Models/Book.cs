using System.ComponentModel.DataAnnotations;
using BookStoreApp.Validation;

namespace BookStoreApp.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required, StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required, StringLength(150)]
        public string Author { get; set; } = string.Empty;

        [Required, Isbn]
        public string ISBN { get; set; } = string.Empty;

        [PriceRange(1, 10000)]
        public decimal Price { get; set; }

        public string Slug() => Title.ToLower().Replace(' ', '-');
    }
}
