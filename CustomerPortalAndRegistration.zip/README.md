# W4 Day 4 – Daily Coding Assignments (ASP.NET Core Razor Pages)

This single ASP.NET Core Razor Pages project implements **both assignments**:

- **Assignment 1: Customer Feedback Portal**
  - Uses **FormTagHelper** and **AnchorTagHelper** for forms/nav.
  - Uses **HTML Helper methods** (`Html.TextBoxFor`, `Html.TextAreaFor`) and a **custom HTML Helper** (`StyledTextBoxFor`).
  - Includes a **custom TagHelper** (`<star-rating asp-for="Input.Rating" max="5" />`) that renders a star rating widget.
  - In-memory store displays submitted feedback on `/Feedback/List`.

- **Assignment 2: Registration & Validation System**
  - `UserRegistration` model with Data Annotations (required, email, length).
  - **Custom validation attribute** `[MatchProperty("Password")]` to ensure password confirmation matches.
  - Razor Page shows **validation summary** and **field-level messages**.
  - **Client-side validation** with jQuery Validate + Unobtrusive via CDN.

## Prerequisites
- .NET 7 SDK or newer

## Run
```bash
dotnet restore
dotnet run
```
Then open `https://localhost:5001` (or the URL shown in the console).

## Project Notes
- Custom TagHelper is in `TagHelpers/StarRatingTagHelper.cs`.
- Custom HTML Helper is in `HtmlHelpers/HtmlHelperExtensions.cs`.
- Custom validation attribute is in `Validation/MatchPropertyAttribute.cs`.
- Feedback is stored in-memory in `Services/FeedbackRepository.cs` (no database required).
- Client-side validation libraries are referenced in `_Layout.cshtml` via CDN.
