using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq.Expressions;

namespace CustomerPortalAndRegistration.HtmlHelpers;

public static class HtmlHelperExtensions
{
    /// <summary>
    /// Renders a styled textbox with placeholder and css classes.
    /// </summary>
    public static IHtmlContent StyledTextBoxFor<TModel, TValue>(
        this IHtmlHelper<TModel> htmlHelper,
        Expression<Func<TModel, TValue>> expression,
        string placeholder,
        string cssClass = "form-control")
    {
        var attrs = new { @class = cssClass, placeholder = placeholder };
        return htmlHelper.TextBoxFor(expression, attrs);
    }
}
