using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CustomerPortalAndRegistration.Models;
using CustomerPortalAndRegistration.Services;

namespace CustomerPortalAndRegistration.Pages.Feedback;

public class IndexModel : PageModel
{
    [BindProperty]
    public Feedback Input { get; set; } = new();

    public void OnGet() { }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        Input.CreatedAt = DateTime.UtcNow;
        FeedbackRepository.Add(Input);
        TempData["Msg"] = "Thanks! Your feedback has been recorded.";
        return RedirectToPage("List");
    }
}
