using Microsoft.AspNetCore.Mvc.RazorPages;
using CustomerPortalAndRegistration.Models;
using CustomerPortalAndRegistration.Services;

namespace CustomerPortalAndRegistration.Pages.Feedback;

public class ListModel : PageModel
{
    public IEnumerable<Feedback> Items { get; set; } = Enumerable.Empty<Feedback>();

    public void OnGet()
    {
        Items = FeedbackRepository.All();
    }
}
