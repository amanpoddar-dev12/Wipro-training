using Microsoft.AspNetCore.Mvc.RazorPages;

public class ErrorModel : PageModel
{
    public void OnGet() { }
}
