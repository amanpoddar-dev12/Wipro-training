using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CustomerPortalAndRegistration.Models;

namespace CustomerPortalAndRegistration.Pages.Registration;

public class IndexModel : PageModel
{
    [BindProperty]
    public UserRegistration Input { get; set; } = new();

    public void OnGet() { }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }
        TempData["Success"] = $"Welcome, {Input.Username}! Registration passed validation.";
        return RedirectToPage("/Registration/Success");
    }
}
