using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CustomerPortalAndRegistration.Pages.Registration;

public class SuccessModel : PageModel
{
    public void OnGet() { }
}
