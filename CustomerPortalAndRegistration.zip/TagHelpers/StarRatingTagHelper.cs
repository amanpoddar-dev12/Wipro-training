using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text;

namespace CustomerPortalAndRegistration.TagHelpers;

[HtmlTargetElement("star-rating", Attributes = ForAttributeName)]
public class StarRatingTagHelper : TagHelper
{
    private const string ForAttributeName = "asp-for";
    private const string MaxAttributeName = "max";

    [HtmlAttributeName(ForAttributeName)]
    public ModelExpression For { get; set; } = default!;

    [HtmlAttributeName(MaxAttributeName)]
    public int Max { get; set; } = 5;

    public override void Process(TagHelperContext context, TagHelperOutput output)
    {
        var inputId = For.Name.Replace(".", "_");
        output.TagName = "div";
        output.Attributes.SetAttribute("class", "star-rating d-inline-block");
        var sb = new StringBuilder();

        // Hidden input bound to model
        sb.Append($@"<input type=""hidden"" id=""{inputId}"" name=""{For.Name}"" value=""{For.Model ?? 0}"" />");

        // Stars
        sb.Append($@"<div class=""stars"" data-target=""{inputId}"">");
        for (int i = 1; i <= Max; i++)
        {
            sb.Append($@"<span class=""star"" data-value=""{i}"">&#9733;</span>");
        }
        sb.Append("</div>");

        // Inline script to handle clicks
        sb.Append(@"
<script>
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.star-rating .star').forEach(function(star) {
    star.addEventListener('click', function() {
      var value = this.getAttribute('data-value');
      var container = this.closest('.star-rating');
      var target = container.querySelector('input[type=hidden]');
      target.value = value;
      container.querySelectorAll('.star').forEach(function(s, idx){
        s.classList.toggle('filled', idx < value);
      });
    });
  });
  // initialize filled state
  document.querySelectorAll('.star-rating').forEach(function(container){
    var target = container.querySelector('input[type=hidden]');
    var val = parseInt(target.value || '0');
    container.querySelectorAll('.star').forEach(function(s, idx){
      s.classList.toggle('filled', (idx+1) <= val);
    });
  });
});
</script>
<style>
.star-rating .star{ cursor:pointer; font-size:1.5rem; }
.star-rating .star.filled{ color:#f5c518; }
</style>
");

        output.Content.SetHtmlContent(sb.ToString());
    }
}
