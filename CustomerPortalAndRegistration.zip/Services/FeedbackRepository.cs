using System.Collections.Concurrent;
using CustomerPortalAndRegistration.Models;

namespace CustomerPortalAndRegistration.Services;

public static class FeedbackRepository
{
    private static readonly ConcurrentBag<Feedback> _store = new();

    public static void Add(Feedback fb) => _store.Add(fb);

    public static IEnumerable<Feedback> All() => _store.OrderByDescending(f => f.CreatedAt);
}
