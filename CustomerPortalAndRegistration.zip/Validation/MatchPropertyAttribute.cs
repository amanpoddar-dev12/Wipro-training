using System;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace CustomerPortalAndRegistration.Validation;

[AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
public class MatchPropertyAttribute : ValidationAttribute
{
    public string OtherProperty { get; }

    public MatchPropertyAttribute(string otherProperty)
    {
        OtherProperty = otherProperty;
    }

    protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
    {
        var type = validationContext.ObjectInstance.GetType();
        var otherProp = type.GetProperty(OtherProperty, BindingFlags.Public | BindingFlags.Instance);
        if (otherProp == null)
        {
            return new ValidationResult($"Unknown property: {OtherProperty}");
        }

        var otherValue = otherProp.GetValue(validationContext.ObjectInstance, null)?.ToString();
        var thisValue = value?.ToString();

        if (string.Equals(thisValue, otherValue))
        {
            return ValidationResult.Success;
        }

        return new ValidationResult(ErrorMessage ?? $"{validationContext.MemberName} must match {OtherProperty}.");
    }
}
